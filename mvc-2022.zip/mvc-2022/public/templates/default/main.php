<main>
<?php 

include VIEW.$content.".php";

?>
<main>