<?php
require_once DIR_TEMPLATE."/header.php";
?>
<main>
    <div style="width:50%; margin:0 auto;">
        <img src="<?php echo URL_TEMPLATE ?>images/em_construcao.jpg"  style="width:100%"/>
    </div>
</main>